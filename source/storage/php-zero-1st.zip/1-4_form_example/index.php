<?php
/**
 * ブラウザで localhost:8000 にアクセス
 *
 * $ cd path/to/dir
 * $ php -S localhost:8000
 */
// 関数定義
/**
 * バリデーション関数
 *
 * 入力項目を検証しエラーがあればメッセージを配列で返す
 *
 * @params array $params
 * @reutrn array
 */
function validate($params)
{
    $errors = [
        'email'   => [],
        'gender'  => [],
        'message' => []
    ];
    if (empty($params['email'])) {
        $errors['email'][] = 'メールアドレスが入力されていません';
    }

    if (!empty($params['email']) && !filter_var($params['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'][] = 'メールアドレスのフォーマットが正しくありません';
    }

    if (empty($params['gender']) || !in_array($params['gender'], ['male', 'female', 'other'])) {
        $errors['gender'][] = '性別は男性, 女性またはその他から洗濯してください';
    }

    if (empty($params['message'])) {
        $errors['message'][] = 'メッセージが入力されていません';
    }

    if (!empty($params['message']) && mb_strlen($params['message']) < 10 || mb_strlen($params['message']) > 200) {
        $errors['message'][] = 'メッセージは 10 文字以上 200 文字以下で入力してください。';
    }

    return $errors;
}

/**
 * エラー表示関数
 *
 * エラーがある場合に適切なフォーマットでエラーを表示する
 *
 * @params array $errors
 */
function htmlError($errors)
{
    if (is_null($errors) || count($errors) === 0) {
        return '';
    }

    $strings = [];
    foreach ($errors as $error) {
        $strings[] = '<p class="help is-danger">' . htmlspecialchars($error, ENT_QUOTES, 'utf-8') . '</p>';
    }
    return join($strings, "\n");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $params = [];
    foreach (['email', 'gender', 'message'] as $key) {
        $params[$key] = (isset($_POST[$key])) ? preg_replace('/(\s|　)/u', '', $_POST[$key]) : null;
    }

    $errors = validate($params);
    if (count($errors['name']) == 0 && count($errors['gender']) === 0 && count($errors['message']) === 0) {
        // メッセージの合成処理しメール送信処理を実行
        // mb_send_mail('inquiry@example.jp', 'お問い合わせがありました', $message);
        $params = [];
        $notification = 'メッセージを送信しました';
    }
}
?>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>example</title>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.css">
    </head>
    <body>
        <div class="container">
            <h1 class="title">お問い合わせフォーム</h1>
            <?php if (isset($notification) && !empty($notification)):?>
                <div class="notification is-info">
                    <?php echo htmlspecialchars($notification, ENT_QUOTES, 'utf-8');?>
                </div>
            <?php endif;?>
            <form method="post">
                <div class="field">
                    <label for="email" class="label">メールアドレス</label>
                    <div class="control">
                    <input id="emai" class="input" type="name" name="email" value="<?php echo $params['email'];?>">
                        <?php echo htmlError($errors['email']);?>
                    </div>
                </div>
                <div class="field">
                    <label for="gender" class="label">性別</label>
                    <div class="control">
                        <label class="radio">
                            <input type="radio" name="gender" value="male"<?php echo ($params['gender'] === 'male') ? ' checked' : '';?>>
                            男性
                        </label>
                        <label class="radio">
                            <input type="radio" name="gender" value="female"<?php echo ($params['gender'] === 'female') ? ' checked' : '';?>>
                            女性
                        </label>
                        <label class="radio">
                            <input type="radio" name="gender" value="other"<?php echo ($params['gender'] === 'other') ? ' checked' : '';?>>
                            その他
                        </label>
                        <?php echo htmlError($errors['gender']);?>
                    </div>
                </div>
                <div class="field">
                    <label for="message" class="label">お問い合わせ内容</label>
                    <div class="control">
                        <textarea id="message" class="textarea" name="message"><?php echo $params['message'];?></textarea>
                        <?php echo htmlError($errors['message']);?>
                    <div>
                </div>
                <div class="field" style="margin-top: 2rem;">
                    <div class="control" style="text-align: right;">
                        <input type="submit" value="送信" class="button is-primary">
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>
