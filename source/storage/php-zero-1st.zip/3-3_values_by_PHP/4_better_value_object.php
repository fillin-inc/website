<?php
/**
 * ValueObject は本来 Immutable であるべき
 *
 * PHP のマジックメソッド(オーバーロード) を利用して動的にプロパティを指定し,
 * 尚且つプロパティの更新ができないようにします。
 */
abstract class ValueObject
{
    protected $_properties = [];

    public function __construct(array $args = [])
    {
        $this->_setProperties();

        foreach ($args as $property => $value) {
            if (in_array($property, $this->_properties)) {
                $this->$property = $args[$property];
            }
        }
    }

    /**
     * ValueObject クラスを継承したクラスの protected なプロパティを列挙
     *
     * ex.
     * class A
     * {
     *     protected $hoge;
     *     protected $fuga;
     * }
     * の場合, ['hoge', 'fuga']
     */
    protected function _setProperties()
    {
        $this->_properties = array_filter(array_map(
            function (\ReflectionProperty $property) {
                // _ 始まりのプロパティは除外
                if (!preg_match('/^_/u', $property->getName())) {
                    return $property->getName();
                }
            },
            (new \ReflectionObject($this))
                ->getProperties(\ReflectionProperty::IS_PROTECTED)
        ));
    }

    public function __get($name)
    {
        if (!in_array($name, $this->_properties)) {
            throw new \OutOfBoundsException(
                "{$name} プロパティは存在しません。protected プロパティを定義する必要があります。"
            );
        }
        return $this->$name;
    }

    /**
     * __set を未定義とすることでプロパティの更新ができない
     *
    public function __set($name, $value)
    {
        if (!in_array($name, $this->_properties)) {
            throw new \OutOfBoundsException(
                "{$name} プロパティに値を設定することはできません。protected プロパティを定義する必要があります。"
            );
        }
        $this->$name = $value;
    }
    */
}

class Weather extends ValueObject
{
    protected $temperature;
}

$weather = new Weather(['temperature' => 25]);
var_dump($weather->temperature);
