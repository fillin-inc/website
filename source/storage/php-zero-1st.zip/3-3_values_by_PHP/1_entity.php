<?php
/**
 * "一意であるオブジェクト" を Entity と呼ぶ
 *
 * MVC フレームワークの Model はほとんどこれ
 */
class User
{
    /**
     * $id はシステム上常に unique
     */
    private $id;
    private $name;
    private $gender;
}
