<?php
/**
 * https://www.php.net/manual/ja/class.arrayobject.php
 */
class User
{
    private $id;
    private $name;

    public function __construct(int $id, string $name)
    {
        $this->id = $id;
        $this->name = $name;
    }
}

class UserCollection extends ArrayObject
{
}

$users = new UserCollection([new User(1, 'one'), new User(2, 'two')]);
var_dump($users);
