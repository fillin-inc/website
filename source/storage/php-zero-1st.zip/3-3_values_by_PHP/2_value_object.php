<?php
/**
 * 一意性を持たないオブジェクト
 *
 * ex. Web アプリのリクエストデータ
 */
class RequestParam
{
    private $params;
    private $time;

    public function params()
    {
        return $params;
    }
}
