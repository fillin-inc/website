<?php
// 型宣言（type hinting) の利用
class Base
{
    public $name = 'Base';
}

// 引数に型宣言を利用すると与えられるオブジェクトを制限できる
class Obj extends Base
{
    public $name = 'Object Name';
}

function showObject(Obj $obj): void
{
    echo $obj->name . "\n";
}

showObject(new Obj);

// 子クラスであっても動作する
class SubObj extends Obj
{
    public $name = 'Sub Object Name';
}
showObject(new SubObj);

// Obj の親クラスは動作しない
try {
    showObject(new Base);
} catch (Error $e) {
    echo "動作しない\n";
}


/////////////////////////////////////////////////////////////////

// interface の利用

interface ICall
{
    public function call(): void;
}

class Phone implements ICall
{
    public function call(): void
    {
        echo "Ring Ring\n";
    }
}

class Mobile implements ICall
{
    public function call(): void
    {
        echo "RiRiRiRi\n";
    }
}

function showCall(ICall $obj)
{
    $obj->call();
}

showCall(new Phone);
showCall(new Mobile);
