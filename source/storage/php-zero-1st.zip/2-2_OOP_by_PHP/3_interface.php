<?php
interface IPayment
{
    public function amount(): int;
    public function execute(): bool;
}

class MyPayment implements IPayment
{
    public function amount(): int
    {
        return 1000;
    }

    public function execute(): bool
    {
        echo $this->amount();
        return true;
    }
}

$payment = new MyPayment();
$payment->execute();
