<?php
// class
class User
{
    // PHP >= 7.4
    // private string $name;
    // private int $age;
    private $name;
    private $age;

    public function __construct(string $name, int $age)
    {
        $this->name = $name;
        $this->age = $age;
    }

    public function info(): string
    {
        return sprintf('name: %s age: %d', $this->name, $this->age);
    }

    public function getName()
    {
        return $this->name;
    }

    public function getAge()
    {
        return $this->age;
    }
}

$user = new User('John Doe', 30);
echo $user->info() . "\n";

try {
    echo $user->name . "\n";
} catch (Error $e) {
    echo "class:" . get_class($e) . " private にはアクセスできません。\n";
}

// extends
class Man extends User
{
    private $gender = 'male';

    public function info():string
    {
        return parent::info() . sprintf(' gender: %s', $this->gender);
    }
}
$man = new Man('John Doe', 30);
echo $man->info() . "\n";
