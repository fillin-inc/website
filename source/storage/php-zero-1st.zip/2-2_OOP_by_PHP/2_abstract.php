<?php
abstract class Sample
{
    abstract protected function message(): string;

    public function say(): void
    {
        echo $this->message();
    }
}
try {
    // 抽象クラスはインスタンス化できない
    $abstract = new Sample();
} catch (Error $e) {
    echo "class:" . get_class($e) . " " . $e->getMessage() . "\n";
}

class Hello extends Sample
{
    protected function message(): string
    {
        return 'Message';
    }
}

$hello = new Hello();
$hello->say();
