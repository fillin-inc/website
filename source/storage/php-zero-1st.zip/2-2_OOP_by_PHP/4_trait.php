<?php
// trait
//
// Ruby の Module 相当
// メソッドやプロパティを定義して class に include できる
trait WithTimestamp
{
    /**
     * 作成日時
     */
    public $created_at;

    /**
     * 更新日時
     */
    public $updated_at;
}

class Product
{
    use WithTimestamp;
    public $name;

    public function __construct(string $name)
    {
        $this->name = $name;
        $this->created_at = new DateTime();
    }
}

$product = new Product('新しいチョッパやシステム');
echo $product->name . "\n";
echo $product->created_at->format('Y-m-d H:i:s') . "\n";
