<?php
/**
 * ブラウザで localhost:8000 にアクセス
 *
 * $ cd path/to/dir
 * $ php -S localhost:8000
 */
require_once './src/boot.php';

use App\Helper;

$inquiry = new App\Models\Inquiry($_POST);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if ($_POST['_cstf_token'] !== session_id()) {
            session_regenerate_id();
            throw new Exception('不正なリクエストが行われました');
        }

        if ($inquiry->validate()) {
            // メッセージの合成処理しメール送信処理を実行
            $notification = 'メッセージを送信しました';
            $inquiry = new App\Models\Inquiry();
        }
    } catch (Exception $e) {
        echo $e->getMessage();
        exit;
    }
}
?>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>example</title>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.css">
    </head>
    <body>
        <div class="container">
            <h1 class="title">お問い合わせフォーム</h1>
            <?php if (isset($notification) && !empty($notification)):?>
                <div class="notification is-info">
                    <?php echo Helper::h($notification);?>
                </div>
            <?php endif;?>
            <form method="post">
                <div class="field">
                    <label for="email" class="label">メールアドレス</label>
                    <div class="control">
                        <input id="emai" class="input" type="name" name="email" value="<?php echo $inquiry->email;?>">
                        <?php echo Helper::htmlError($inquiry->errors()['email']);?>
                    </div>
                </div>
                <div class="field">
                    <label for="message" class="label">お問い合わせ内容</label>
                    <div class="control">
                        <textarea id="message" class="textarea" name="message"><?php echo $Inquiry->message;?></textarea>
                        <?php echo Helper::htmlError($inquiry->errors()['message']);?>
                    <div>
                </div>
                <div class="field" style="margin-top: 2rem;">
                    <div class="control" style="text-align: right;">
                        <input type="submit" value="送信" class="button is-primary">
                    </div>
                </div>
                <input type="hidden" name="_cstf_token" value="<?php echo session_id();?>">
            </form>
        </div>
    </body>
</html>
