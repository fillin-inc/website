<?php

namespace App\Helpers;

trait Error
{
    /**
     * エラーメッセージ取得
     *
     * @param null|array $errors
     * @return string
     */
    public static function htmlError($errors): string
    {
        if (is_null($errors) || count($errors) === 0) {
            return '';
        }

        $strings = [];
        foreach ($errors as $error) {
            $strings[] = '<p class="help is-danger">' . \App\Helper::h($error->getMessage()) . '</p>';
        }
        return join($strings, "\n");
    }
}
