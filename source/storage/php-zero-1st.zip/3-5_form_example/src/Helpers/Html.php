<?php
namespace App\Helpers;

trait Html
{
    /**
     * h メソッド
     *
     * 文字列に対してエスケープ処理
     *
     * @param string $str
     * @return string
     */
    public static function h(string $str): string
    {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}
