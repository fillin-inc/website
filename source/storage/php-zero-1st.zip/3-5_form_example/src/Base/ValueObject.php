<?php
namespace App\Base;

abstract class ValueObject
{
    protected $_properties = [];

    public function __construct(array $args = [])
    {
        $this->_setProperties($args);

        foreach ($args as $property => $value) {
            if (in_array($property, $this->_properties)) {
                $this->$property = $args[$property];
            }
        }
    }

    protected function _setProperties(array $args)
    {
        $this->_properties = array_filter(array_map(
            function (\ReflectionProperty $property) {
                // _ 始まりのプロパティは除外
                if (!preg_match('/^_/u', $property->getName())) {
                    return $property->getName();
                }
            },
            (new \ReflectionObject($this))
                ->getProperties(\ReflectionProperty::IS_PROTECTED)
        ));
    }

    public function __get($name)
    {
        if (!in_array($name, $this->_properties)) {
            throw new \OutOfBoundsException(
                "{$name} プロパティは存在しません。protected プロパティを定義する必要があります。"
            );
        }
        return $this->$name;
    }
}
