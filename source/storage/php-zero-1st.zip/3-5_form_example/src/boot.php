<?php
define('ROOT', realpath(__DIR__ . '/..'));
require_once ROOT . '/vendor/autoload.php';

foreach (glob(ROOT . '/src/Base/*') as $path) {
    require_once $path;
}

foreach (glob(ROOT . '/src/Models/*') as $path) {
    if (is_dir($path)) {
        foreach (glob($path . '/*') as $sub_path) {
            require_once $sub_path;
        }
    } else {
        require_once $path;
    }
}
require_once ROOT . '/src/Helper.php';

session_start();
