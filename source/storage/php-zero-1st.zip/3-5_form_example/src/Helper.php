<?php
namespace App;

foreach (glob(ROOT . '/src/Helpers/*.php') as $path) {
    require_once $path;
}

class Helper
{
    use Helpers\Html;
    use Helpers\Error;
}
