<?php
namespace App\Models;

use \App\Base\ValueObject;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;

class Inquiry extends ValueObject
{
    use Concerns\Validationable;

    /**
     * メールアドレス
     *
     * @var string
     */
    protected $email;

    /**
     * お問い合わせ内容
     *
     * @var string
     */
    protected $message;

    /**
     * バリデーション設定
     *
     * @param Symfony\Component\Validator\Mapping\ClassMetadata $metadata
     * @return void
     */
    public static function loadValidatorMetadata(ClassMetadata $metadata): void
    {
        $metadata->addPropertyConstraint('email', new Assert\NotBlank());
        $metadata->addPropertyConstraint('email', new Assert\Email());

        $metadata->addPropertyConstraint('message', new Assert\NotBlank());
        $metadata->addPropertyConstraint('message', new Assert\Length(['min' => 10, 'max' => 200]));
    }
}
