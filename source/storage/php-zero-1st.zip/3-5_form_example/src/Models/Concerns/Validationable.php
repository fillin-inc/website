<?php
namespace App\Models\Concerns;

use Symfony\Component\Validator\Validation;

/**
 * Validationable クラス
 *
 * model に対してバリデーション機能を付与する
 */
trait Validationable
{
    /**
     * バリデーションエラー
     *
     * @var []Symfony\Component\Validator\ConstraintViolation エラーに対応する要素毎に配列で保持
     */
    private $validation_errors = [];

    /**
     * バリデーション設定メソッド
     *
     * @param $metadata ClassMetadata
     * @return void
     */
    abstract public static function loadValidatorMetadata(ClassMetadata $metadata): void;

    /**
     * バリデーション実行
     *
     * @return bool
     */
    public function validate(): bool
    {
        $validator = Validation::createValidatorBuilder()
            ->addMethodMapping('loadValidatorMetadata')
            ->getValidator();

        foreach ($validator->validate($this) as $error) {
            if (array_key_exists($error->getPropertyPath(), $this->validation_errors)) {
                $this->validation_errors[$error->getPropertyPath()] = [];
            }
            $this->validation_errors[$error->getPropertyPath()][] = $error;
        }

        return empty($this->validation_errors);
    }

    /**
     * エラー情報取得
     *
     * @return array
     */
    public function errors(): array
    {
        return $this->validation_errors;
    }
}
